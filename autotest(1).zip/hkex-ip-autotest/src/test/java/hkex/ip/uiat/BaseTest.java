package hkex.ip.uiat;

import hkex.ip.uiat.dto.BaseDto;
import hkex.ip.uiat.driver.BasePageFactory;
import hkex.ip.uiat.driver.BrowserFactory;
import hkex.ip.uiat.page.LoginPage;
import hkex.ip.uiat.report.TestListener;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.annotations.*;

import static hkex.ip.uiat.config.ConfigurationManager.configuration;

@Slf4j
@Listeners(TestListener.class)
public abstract class BaseTest {

    public final WebDriver driver =
            BrowserFactory.valueOf(configuration().browser().toUpperCase()).getDriver();

    protected LoginPage loginPage;

    protected String getTestDataFilePath(String path) {
        return configuration().baseTestDataPath() + path;
    }

    @BeforeClass(alwaysRun = true)
    public void setup() {
        loginPage = BasePageFactory.createInstance(driver, LoginPage.class);
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        driver.quit();
    }

    @BeforeMethod(alwaysRun = true)
    public void testSatrt(ITestResult result) {
        if (result.getParameters().length > 0) {
            BaseDto data = (BaseDto) result.getParameters()[0];
            log.info("**" + data);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void captureScreenshotOnFailure(ITestResult result) {
        ITestNGMethod method = result.getMethod();
        if (ITestResult.FAILURE == result.getStatus()) {
            loginPage.captureScreenshot(
                    String.format(
                            "%s_%s_%s",
                            method.getRealClass().getSimpleName(),
                            method.getMethodName(),
                            method.getParameterInvocationCount()));
        }
    }

}
