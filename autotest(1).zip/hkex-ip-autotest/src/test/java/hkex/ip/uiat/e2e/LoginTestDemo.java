package hkex.ip.uiat.e2e;

import hkex.ip.uiat.BaseTest;
import hkex.ip.uiat.dto.LoginDto;
import hkex.ip.uiat.util.TestRetry;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

import static hkex.ip.uiat.util.DataProviderUtil.processTestData;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

/**
 * @author ocft
 */
@Slf4j
public final class LoginTestDemo extends BaseTest {
    private static final String FILE_PATH = "login.json";

    @DataProvider(name = "loginData")
    public Object[][] getLoginData(final Method testMethod) {
        String testCaseId = testMethod.getAnnotation(Test.class).testName();
        return processTestData(LoginDto.class, getTestDataFilePath(FILE_PATH), testCaseId);
    }


    @Test(testName = "TC-1", dataProvider = "loginData", retryAnalyzer = TestRetry.class)
    public void testCorrectUserNameAndCorrectPassword(final LoginDto data) {

        loginPage.loginAs(data.getUsername(), data.getPassword());
        log.info("testCorrectUserNameAndCorrectPassword");
        assertThat(loginPage.getTitle()).isEqualTo("Products");
    }

    @Test(testName = "TC-2", dataProvider = "loginData", retryAnalyzer = TestRetry.class)
    public void testImproperCredentialsShouldGiveErrorMessage(final LoginDto data) {
        loginPage.loginAs(data.getUsername(), data.getPassword());
        log.info("testImproperCredentialsShouldGiveErrorMessage");
        assertThat(loginPage.getErrorMessage()).isEqualTo(data.getErrorMessage());
    }

}
