package hkex.ip.uiat.e2e;

import hkex.ip.uiat.BaseTest;
import hkex.ip.uiat.dto.ProductsDto;
import hkex.ip.uiat.driver.BasePageFactory;
import hkex.ip.uiat.page.ProductsPage;
import hkex.ip.uiat.util.TestRetry;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static hkex.ip.uiat.util.DataProviderUtil.processTestData;

/**
 * @author ocft
 */
@Slf4j
public final class ProductsTestDemo extends BaseTest {

    private static final String FILE_PATH = "products.json";

    @DataProvider(name = "productsData")
    public Object[][] getProductsData(final Method testMethod) {
        String testCaseId = testMethod.getAnnotation(Test.class).testName();

        return processTestData(ProductsDto.class, getTestDataFilePath(FILE_PATH), testCaseId);
    }


    @Test(testName = "TC-1",dataProvider = "productsData",retryAnalyzer = TestRetry.class)
    public void testAddtoCart(final ProductsDto data) {
        loginPage.loginAs(data.getLoginData().getUsername(), data.getLoginData().getPassword());

        var productsPage = BasePageFactory.createInstance(driver, ProductsPage.class);
        String getTitle = productsPage.ClickAdd2Cart();
        log.info("this is a test about add to cart");
        assertThat(getTitle).isEqualTo(data.getProductsData().getExpectedResults());
    }

    @Test(testName = "TC-2",dataProvider = "productsData",retryAnalyzer = TestRetry.class)
    public void testRemove(final ProductsDto data) {

        loginPage.loginAs(data.getLoginData().getUsername(), data.getLoginData().getPassword());

        var productsPage = BasePageFactory.createInstance(driver, ProductsPage.class);
        String getTitle = productsPage.ClickRemove();
        log.info("this is a test about remove from cart");
        assertThat(getTitle).isEqualTo(data.getProductsData().getExpectedResults());
    }


}
