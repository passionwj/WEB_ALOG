package hkex.ip.uiat.dto;

import com.univocity.parsers.annotations.Parsed;
import lombok.Getter;
import lombok.ToString;

/**
 * @author ocft
 */


@Getter
@ToString(callSuper = true)
public final class ProductsDto extends BaseDto {

    @Parsed(field = "login Data", defaultNullRead = "")
    private loginData loginData;

    @Parsed(field = "active", defaultNullRead = "")
    private productsData productsData;

    @Getter
    @ToString(callSuper = true)
    public final class loginData{
        @Parsed(field = "Username", defaultNullRead = "")
        private String username;

        @Parsed(field = "Password", defaultNullRead = "")
        private String password;

    }
    @Getter
    @ToString(callSuper = true)
    public final class productsData{
        @Parsed(field = "active", defaultNullRead = "")
        private String active;

        @Parsed(field = "expected results", defaultNullRead = "")
        private String expectedResults;
    }



}

