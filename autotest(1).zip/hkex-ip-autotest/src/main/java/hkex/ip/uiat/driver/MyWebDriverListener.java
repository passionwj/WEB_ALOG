package hkex.ip.uiat.driver;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverListener;


/**
 * author: ocft
 * function：A listener class that prints a log before and after the execution of a WebElement element.
 */
@Slf4j
public class MyWebDriverListener implements WebDriverListener {

    public void beforeFindElements(WebDriver driver, By locator) {
        log.info("MyWebDriverListener beforeFindBy is: " + locator.toString());
    }

//    public void afterFindElements(WebDriver driver, By locator, List<WebElement> result) {
//        //编写监听 WebDriver.findElement(...), or WebDriver.findElements(...), or WebElement.findElement(...), or WebElement.findElements(...). 操作后的代码
//        log.info("MyWebDriverListener afterFindBy is: " + locator.toString());
//    }

    public void beforeSendKeys(WebElement element, CharSequence... keysToSend) {
        log.info("MyWebDriverListener beforeSendKeys: " + keysToSend.toString());
    }

//    public void afterSendKeys(WebElement element, CharSequence... keysToSend) {
//        log.info("MyWebDriverListener afterSendKeys: " + keysToSend.toString());
//    }

    //再点击按钮之前
    public void beforeClick(WebElement element) {
        //String text = element.getText();
        String attribute = element.getAttribute("");
        //WebElement element1 = element.findElement(By.tagName("));
        log.info("MyWebDriverListener beforeClick: " + attribute);
    }

    //在点击按钮之后，对于登录按钮，点击之后会跳转到 商城首页，
    public void afterClick(WebElement element) {
    }
//
//    public void beforeSubmit(WebElement element) {
//        //String text = element.getText();
//        log.info("MyWebDriverListener beforeSubmit: " + tagName);
//    }
}
