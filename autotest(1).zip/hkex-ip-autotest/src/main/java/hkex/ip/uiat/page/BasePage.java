package hkex.ip.uiat.page;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static hkex.ip.uiat.config.ConfigurationManager.configuration;

/**
 * @author ocft
 */
public abstract class BasePage {

    protected WebDriver driver;

    public void initDriverAndElements(final WebDriver webdriver) {
        this.driver = webdriver;
        PageFactory.initElements(driver, this);
    }

    public void initComponents() {
    }

    public String getUrl() {
        return driver.getCurrentUrl();
    }

    //
    public void captureScreenshot(String fileName) {
        Shutterbug.shootPage(driver).withName(fileName).save(configuration().baseScreenshotPath());
    }
}
