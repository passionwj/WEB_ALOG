package hkex.ip.uiat.page;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import hkex.ip.uiat.page.component.Header;
import hkex.ip.uiat.page.component.SideNavMenu;

@Slf4j
public class ProductsPage extends BasePage {

    private Header header;
    private SideNavMenu sideNavMenu;

    @FindBy(className = "title")
    private WebElement Title;


    @FindBy(xpath = "//*[@id=\"add-to-cart-sauce-labs-backpack\"]")
    private WebElement Add2Cart;

    @FindBy(id = "remove-sauce-labs-backpack")
    private WebElement Remove;

    @Override
    public void initComponents() {
        header = new Header(driver);
        sideNavMenu = new SideNavMenu(driver);
    }
    public String ClickAdd2Cart(){
        Add2Cart.click();
        log.info("click add to cart");
        return Remove.getText();
    }

    public String ClickRemove(){
        Remove.click();
        log.info("click remove");
        return Add2Cart.getText();
    }

}
