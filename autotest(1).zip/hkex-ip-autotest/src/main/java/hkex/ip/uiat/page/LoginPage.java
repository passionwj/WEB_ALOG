package hkex.ip.uiat.page;

import hkex.ip.uiat.factory.BasePageFactory;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static hkex.ip.uiat.config.ConfigurationManager.configuration;

/**
 * @author ocft
 */
@Slf4j
public final class LoginPage extends BasePage {

    @FindBy(id = "user-name")
    private WebElement txtUsername;

    @FindBy(id = "password")
    private WebElement txtPassword;

    @FindBy(id = "login-button")
    private WebElement btnLogin;

    @FindBy(id = "logout-button")
    private WebElement btnLogout;

    @FindBy(className = "title")
    private WebElement lblTitle;

    @FindBy(className = "error-message-container")
    private WebElement errorMessage;

    public LoginPage openUrl() {
        driver.get(configuration().baseUrl());
        return this;
    }

    private void clearAndType(final WebElement elem, final String text) {
        elem.clear();
        elem.sendKeys(text);
    }

    public LoginPage typeUsername(final String username) {
        clearAndType(txtUsername, username);
        log.info("type username");
        return this;
    }

    public LoginPage typePassword(final String password) {
        clearAndType(txtPassword, password);
        log.info("type password");
        return this;
    }

    public String getErrorMessage() {
        return this.errorMessage.findElement(By.tagName("h3"))
                .getText();
    }

    public LoginPage clickLogin() {
        btnLogin.click();
        return BasePageFactory.createInstance(driver, LoginPage.class);
    }

    public LoginPage clickLogout() {
        btnLogout.click();
        log.info("click logout");
        return this;
    }

    public String getTitle() {
        return lblTitle.getText();
    }

    public LoginPage loginAs(String username, String password) {
        openUrl();
        typeUsername(username);
        typePassword(password);
        return clickLogin();
    }

    public LoginPage logoutAs() {
        return clickLogout();
    }
}
