package hkex.ip.uiat.driver;

import hkex.ip.uiat.util.HeadlessNotSupportedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.events.EventFiringDecorator;

import java.time.Duration;

import static hkex.ip.uiat.driver.BrowserData.*;
import static hkex.ip.uiat.config.ConfigurationManager.configuration;
import static java.lang.Boolean.TRUE;

/**
 * @author ocft
 */
public enum BrowserFactory {

    CHROME {
        @Override
        public WebDriver getDriver() {
            WebDriver driver = new ChromeDriver(getOptions());

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(configuration().timeout()));
            driver.manage().window().maximize();
            MyWebDriverListener listener = new MyWebDriverListener();//Create instance of Listener Class
            EventFiringDecorator<WebDriver> decorator = new EventFiringDecorator<>(listener); //Pass listener to constructor
            driver = decorator.decorate(driver);

            return driver;
        }

        @Override
        public ChromeOptions getOptions() {
            var chromeOptions = new ChromeOptions();
            chromeOptions.addArguments(START_MAXIMIZED);
            chromeOptions.addArguments(DISABLE_INFOBARS);
            chromeOptions.addArguments(DISABLE_NOTIFICATIONS);
            chromeOptions.addArguments(REMOTE_ALLOW_ORIGINS);

            if (configuration().headless()) chromeOptions.addArguments(CHROME_HEADLESS);

            return chromeOptions;
        }
    }, FIREFOX {
        @Override
        public WebDriver getDriver() {
            WebDriver driver = new FirefoxDriver(getOptions());

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(configuration().timeout()));
            driver.manage().window().maximize();

            MyWebDriverListener listener = new MyWebDriverListener();//Create instance of Listener Class
            EventFiringDecorator<WebDriver> decorator = new EventFiringDecorator<>(listener); //Pass listener to constructor
            driver = decorator.decorate(driver);
            return driver;
        }

        @Override
        public FirefoxOptions getOptions() {
            var firefoxOptions = new FirefoxOptions();
            firefoxOptions.addArguments(START_MAXIMIZED);

            if (configuration().headless()) firefoxOptions.addArguments(GENERIC_HEADLESS);

            return firefoxOptions;
        }
    }, EDGE {
        @Override
        public WebDriver getDriver() {
            WebDriver driver = new EdgeDriver(getOptions());

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(configuration().timeout()));
            driver.manage().window().maximize();
            MyWebDriverListener listener = new MyWebDriverListener();//Create instance of Listener Class
            EventFiringDecorator<WebDriver> decorator = new EventFiringDecorator<>(listener); //Pass listener to constructor
            driver = decorator.decorate(driver);

            return driver;
        }

        @Override
        public EdgeOptions getOptions() {
            var edgeOptions = new EdgeOptions();
            edgeOptions.addArguments(START_MAXIMIZED);

            if (configuration().headless()) edgeOptions.addArguments(GENERIC_HEADLESS);

            return edgeOptions;
        }
    }, SAFARI {
        @Override
        public WebDriver getDriver() {
            WebDriver driver = new SafariDriver(getOptions());

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(configuration().timeout()));
            driver.manage().window().maximize();

            MyWebDriverListener listener = new MyWebDriverListener();//Create instance of Listener Class
            EventFiringDecorator<WebDriver> decorator = new EventFiringDecorator<>(listener); //Pass listener to constructor
            driver = decorator.decorate(driver);
            return driver;
        }

        @Override
        public SafariOptions getOptions() {
            var safariOptions = new SafariOptions();
            safariOptions.setAutomaticInspection(false);

            if (TRUE.equals(configuration().headless()))
                throw new HeadlessNotSupportedException(safariOptions.getBrowserName());

            return safariOptions;
        }
    };

    public abstract AbstractDriverOptions<?> getOptions();

    public abstract WebDriver getDriver();
}
