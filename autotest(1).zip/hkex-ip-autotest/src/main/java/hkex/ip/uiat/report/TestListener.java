package hkex.ip.uiat.report;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import hkex.ip.uiat.dto.BaseDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringEscapeUtils;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import static hkex.ip.uiat.config.ConfigurationManager.configuration;

/**
 * @author ocft
 */
@Slf4j
public class TestListener implements ITestListener {

    private static final ExtentReports REPORT = ExtentReportManager.createReport();

    @Override
    public void onTestSuccess(ITestResult result) {
        log.info("TestListener onTestSuccess start...");

        ITestNGMethod method = result.getMethod();
        String testCaseId = "#";
        String testCaseDescription = "";
        String testData = "No data parameters are found.";

        if (result.getParameters().length > 0) {
            BaseDto data = (BaseDto) result.getParameters()[0];
            testCaseId = data.getTestCaseId();
            testCaseDescription = data.getTestCaseDescription();
            testData = StringEscapeUtils.escapeHtml4(data.toString());
        }


        ExtentTest extentTest = REPORT.createTest(String.format("[%s] %s", testCaseId, method.getMethodName()))
                .assignCategory(method.getRealClass().getSimpleName());
        extentTest.pass(
                String.format(
                        "<b>Test Case Description:</b> %s<br><br><b>Test Data:</b> %s<br><br><b>Test Execution Time:</b> <i>%.3f</i> seconds",
                        testCaseDescription,
                        testData,
                        (double) (result.getEndMillis() - result.getStartMillis())
                                / 1000.0));
        log.info("TestListener onTestSuccess ended...");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        log.info("TestListener onTestFailure start...");
        ITestNGMethod method = result.getMethod();
        String testCaseId = "#";
        String testCaseDescription = "";
        String testData = "No data parameters are found.";

        if (result.getParameters().length > 0) {
            BaseDto data = (BaseDto) result.getParameters()[0];
            testCaseId = data.getTestCaseId();
            testCaseDescription = data.getTestCaseDescription();
            testData = StringEscapeUtils.escapeHtml4(data.toString());
        }

        REPORT.createTest(String.format("[%s] %s", testCaseId, method.getMethodName()))
                .assignCategory(method.getRealClass().getSimpleName())
                .fail(
                        String.format(
                                "<b>Test Case Description:</b> %s<br><br><b>Test Data:</b> %s<br><br><b>Test Execution Time:</b> <i>%.3f</i> seconds",
                                testCaseDescription,
                                testData,
                                (double) (result.getEndMillis() - result.getStartMillis())
                                        / 1000.0))
                .fail(
                        result.getThrowable(),
                        MediaEntityBuilder.createScreenCaptureFromPath(
                                        String.format(
                                                "../../%s%s_%s_%s.png",
                                                configuration().baseScreenshotPath(),
                                                method.getRealClass().getSimpleName(),
                                                method.getMethodName(),
                                                method.getParameterInvocationCount()))
                                .build());
        log.info("TestListener onTestFailure ended...");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        log.info("TestListener onTestSkipped start...");
        ITestNGMethod method = result.getMethod();
        String testCaseId = "#";
        String testCaseDescription = "";
        String testData = "No data parameters are found.";

        if (result.getParameters().length > 0) {
            BaseDto data = (BaseDto) result.getParameters()[0];
            testCaseId = data.getTestCaseId();
            testCaseDescription = data.getTestCaseDescription();
            testData = StringEscapeUtils.escapeHtml4(data.toString());
        }

        REPORT.createTest(String.format("[%s] %s", testCaseId, method.getMethodName()))
                .assignCategory(method.getRealClass().getSimpleName())
                .skip(
                        String.format(
                                "<b>Test Case Description:</b> %s<br><br><b>Test Data:</b> %s<br><br><b>Test Execution Time:</b> <i>%.3f</i> seconds",
                                testCaseDescription,
                                testData,
                                (double) (result.getEndMillis() - result.getStartMillis())
                                        / 1000.0));
        log.info("TestListener onTestSkipped ended...");
    }

    @Override
    public void onFinish(ITestContext context) {
        log.info("TestListener onFinish ended...");
        REPORT.flush();

        changeContent(ExtentReportManager.fileName, getFileName());
        log.info("TestListener onFinish ended...");
    }


    private static void changeContent(String filePath, String savePath) {
        log.info(STR."generateReport changeContent :  \{filePath}, \{savePath}");
        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            // The following reads and writes are converted to UTF-8 to prevent garbage.
            br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(savePath), "UTF-8"));
            String line = null;
            while ((line = br.readLine()) != null && (line != "")) {
                bw.write(line.replaceAll(Constants.SPARK_SCRIPT, Constants.SPARK_SCRIPT_REPLACEMENT)
                        .replaceAll(Constants.JSONTREE, Constants.JSONTREE_REPLACEMENT)
                        .replaceAll(Constants.FONT_AWESOME, Constants.FONT_AWESOME_REPLACEMENT)
                        .replaceAll(Constants.SPARK_STYLE, Constants.SPARK_STYLE_REPLACEMENT)
                        .replaceAll(Constants.LOGPNG, Constants.LOGPNG_REPLACEMENT));
            }

            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
                if (bw != null) {
                    bw.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        log.info("generateReport changeContent ended.....");
        //Delete the originally generated file
        File file = new File(filePath);
        if (file.exists()) {
            if (file.delete()) {
                log.info("File deleted successfully！");
            } else {
                log.info("File Deletion Failure！");
            }
        } else {
            log.info("File does not exist！");
        }

    }

    private String getFileName() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");//Get current time
        String dateStr = simpleDateFormat.format(new Date());
        return STR."\{Constants.FILE_NAME_PREFIX}\{dateStr}\{Constants.FILE_NAME_SUFFIX}";
    }
}
