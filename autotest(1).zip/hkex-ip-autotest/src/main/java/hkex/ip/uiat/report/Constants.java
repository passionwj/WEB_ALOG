package hkex.ip.uiat.report;

public class Constants {

    public static final String SPARK_SCRIPT = "https://cdn.jsdelivr.net/gh/extent-framework/extent-github-cdn@d6562a79075e061305ccfdb82f01e5e195e2d307/spark/js/spark-script.js";
    public static final String SPARK_SCRIPT_REPLACEMENT = "../../src/main/resources/static/spark-script.js";

    public static final String JSONTREE = "https://cdn.jsdelivr.net/gh/extent-framework/extent-github-cdn@7cc78ce/spark/js/jsontree.js";
    public static final String JSONTREE_REPLACEMENT = "../../src/main/resources/static/extLibs/jsontree.js";

    public static final String FONT_AWESOME = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css";
    public static final String FONT_AWESOME_REPLACEMENT = "../../src/main/resources/static/font-awesome-4.7.0/css/font-awesome.css";

    public static final String SPARK_STYLE = "https://cdn.jsdelivr.net/gh/extent-framework/extent-github-cdn@d6562a79075e061305ccfdb82f01e5e195e2d307/spark/css/spark-style.css";
    public static final String SPARK_STYLE_REPLACEMENT = "../../src/main/resources/static/extLibs/spark-style.css";

    public static final String LOGPNG = "https://cdn.jsdelivr.net/gh/extent-framework/extent-github-cdn@b00a2d0486596e73dd7326beacf352c639623a0e/commons/img/logo.png";
    public static final String LOGPNG_REPLACEMENT = "../../src/main/resources/static/picture/logo.png";

    public static String FILE_NAME_PREFIX = "test-output/testNgReport/autoTestReport";
    public static String TEST_NG_REPORT = "/testNgReport";
    public static String FILE_NAME_SUFFIX = ".html";

}
